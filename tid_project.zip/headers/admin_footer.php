<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Footer</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
		<style type="text/css">

#copy{
				color:white ;
				text-align: center;
				border: 2px solid white;
				background-color: #111D57;
			}

#footer{
	
	height: 230px;
	margin-top: 2%;
	background-color:#111D57 ;
	color: white;
}



</style>	
			<link rel="stylesheet" type="text/css" href="fontawsome/css/all.css">
</head>
<body>

			<!-- Begining of footer -->
					<div class="row" id="footer">
						<div class="col mt-3">
							<h3>CONTACT US </h3>
							<i class="fa-solid fa-envelope fa-1x"></i> tidloanfinance@gmail.com<br>
							<i class="fa-solid fa-phone"></i> +2349069224767<br>
							<i class="fa fa-globe"></i> 2b Bola Onasanya street off Adio-Somoye Street<br>Ogudu, Gra, Ogudu. Ojota <br>Lagos, Nigeria.
						</div>
						<div class="col mt-3">
							<a href=""><img src="../image/twitter.png" alt="twit" style="height:70px"></a>
						<p>Reach us via</p>
						</div>
						<div class="col mt-3">
							<a href=""><img src="../image/facebook2.png" alt="twit" style="height:70px"></a>
						<p>Reach us via </p>
						</div>
						<div class="col mt-3">
							<a href=""><img src="../image/linked_in.png" alt="twit" style="height:70px"></a>
						<p>Reach us via </p>
						</div>
							
						
					</div>

					<!-- End of filter -->

							<!-- copywrite -->

						<div class="row" id="copy">
							<div class="col">

								<span><strong>&#169; 2022 TID Loan and Finace. All Rights Reserved</strong></span>
							</div>
						</div>

							<!-- End of coywrite -->





<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.js">
				
</script>
</body>
</html>