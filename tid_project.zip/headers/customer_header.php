<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Header</title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<style type="text/css">


	#nav{
	background-color: #111D57;
	color: white;

	
}

#nav2{
	font-size: 20px;
	margin-left: 30%;
	margin-top: 1%;


}

#nav1{
	margin-top: 1%;
	margin-bottom: 1%;
}



</style>	
			<link rel="stylesheet" type="text/css" href="../fontawsome/css/all.css">
</head>
<body>

		 <?php
    // <!-- start session -->
    session_start();

    if(!isset($_SESSION['customer_id'])){
      // redirect to login
      $msg = "you need to login to access this page!";
      echo $msg;
      header("location: login.php?m=$msg");
      // exit can have parenthesis or  not
      exit();
    }
     // echo "<pre>";
     //  print_r($_SESSION);
     // echo"</pre>";

    // sanitize function
    function sanitizeInput($data){
      $data = trim($data);
      $data = htmlspecialchars($data);
      $data = addslashes($data);

      return $data;
    }
  ?>


		<!-- Begining of Nav bar -->
	<div class="row" id="nav">
		<div class="col" id="nav1">
	<a class="navbar-brand" href="index.php"><img src="../image/ttt.jpg" width='100' height="60"></a>
		</div>
		<div class="col" id="nav2">
			<nav class="navbar navbar-expand-lg navbar-white ">
  <div class="container-fluid">
 
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarSupportedContent">
      <ul class="navbar-nav " id="text">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="dashboard.php" style="color:white">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../about.php" style="color:white">About us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="loan.php?m=<?php echo $_SESSION['customer_id'] ?>" style="color:white">Loans</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="investment.php" style="color:white">Investment</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color:white">
              <?php
                if(isset($_SESSION['name'])){
                  echo $_SESSION['name'];
                }
             ?>
          </a>
        
                <li class="nav-item">
          <a class="nav-link" href="logout.php" style="color:white">Logout</a>
        </li>
        </li>
       
      </ul>
     
    </div>
  </div>
</nav>
		</div>
	</div>
		<!-- End of Nav bar -->




	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.js">
				
</script>	
</body>
</html>