	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">

	<meta name="keywords" content="TID LOAN"/>
	<meta name="description" content="TID loan offer quick loan within 24rs, we offer short & long term of investment and operate 24hrs."/>
	<meta name="Keywords" content="loan, quick loan, instant loan, short-term investment,long-term investment, 24hrs loan in lagos, 10% interest loan rate, 15% interest loan rate, low interest loan, less paper work loan, 1m loan service, loan company, licenced financial loan company, no collateral loan,rent loan, school fees loan, car loan services, business loan, pay small small loan installment"/>
	<meta name="Author" content="TID LOAN SERVICES"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
			<title>TID LOAN</title>
		
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
		<style type="text/css">
			
		
	
	
			#txt1{
				
				height: 300px;
				width: 50%;
				margin-top: 7%;
				border-radius: 50%;
				text-align: center;
				background-color: #FFFFFF ;
				color: #111D57;
				margin-left: 3%;

			}

			h1{
				text-align: center;
				font-size: 50px;
				padding-top: 5%;
			}

			#txt2{
				border-radius: 50%;
				height: 300px;
				width: 50%;
				position: absolute;
				margin-left: 70%;
				background-color: #FFFFFF ;
				color: #111D57;
				transform: translate(-50%, -50%);
				margin-top: 10%;
			}

			body{
				background-color: #111D57;
			}

			#img1{
				margin-top: 5%;
				height: 100px;
			}

				#img2{
				margin-top: 10px;
				height: 100px;
				color: white;
			}

					#img3{
				margin-top: 25%;
				height: 100px;
				color: white;
			
			}

				#img4{
				margin-top: 5px;
				height: 100px;
			}

			.roisection{

				background-image: url('image/name.jpg');
				background-position: fixed;
				background-repeat: no-repeat;
				background-size: cover;
				margin-top: 1%;
				height: 600px;
			}

		


			#faq{
				margin-top: 25%;
			

			}
		
			


			#faqborder{
				border: 1px solid red;
				width: 15%;
				margin-left: 40%;
				text-align: center;
				background-color: darkred ;
				
			}

			#arrow{
				position: fixed;
				right: 3%;
				z-index: 2;
		
			}
			#wd{
				color: black;
			}

			#bt{
			
				
				text-decoration: none;
				font-size: 20px;
				color: white;


			}

		</style>	
			<link rel="stylesheet" type="text/css" href="fontawsome/css/all.css">
	</head>
	<body>

					<div class="container-fluid" id="mainDiv">


				<?php

					include_once ("header.php");


				?>

													<!-- arrow up -->

					<div class="row" id="arrow">
						<div class="col">
							<a href="#">
							<img src="image/arrowup.png" alt="myphoto" height="50" width="50">
						</a>
						</div>
					</div>

							<!-- my ROI SECTION -->

							<div class="roisection">

								

								<!-- parent div starts here -->

							<div class="row" id="txt1">
								<div class="col">
									<h1>Get a fast loan<br>of up to<br> <strong style="color: red; text-shadow: 2px 2px 5px red;">ONE Million Naira</strong> <br>today</h1>
								</div>
									</div>


							<div class="row" id="txt2">
								<div class="col">
									<h1>Enjoy<br><strong style="color: red; text-shadow: 2px 2px 5px red;">15% ROI p.a</strong> <br>on your investment <br>today!!!</h1>
								</div>
									</div>

									

									<!-- parent div ends here -->
									</div>



								<!-- Begining of company narration with image -->
									<div class="row" id="img1">
										<div class="col-md-6">
     					 <img src="image/loan.jpg" class="d-block w-100" alt="pic" style="height: 400px;">
    					</div>
  
										<div class="col-md-6" id="img2">
											<img src="image/smile.jpg" alt="pic" style="height: 200px;" class="img-fluid rounded">
											<h2 class="d-none d-md-block">TID LOAN</h2>
					<p class="px-3" id="wd">	We all hate long procedure/requirment in getting a loan from the bank, it’s time wasting and
						frustrating, but with our fast and convenient loan solution, you are gurranteed of swift loan less than 24hrs. Yes, sign up today with us and enjoy an excellect swift loan disbursement with low interest rate..... <a href="registration.php" target="_blank" id="bt"><strong>Sign up</a></strong></p>
										</div>
											
									</div>

			<div class="row" id="img3">
				<div class="col-md-6">
					<img src="image/businessman.jpg" alt="pic" style="height: 200px;" class="img-fluid rounded">
											<h2 class="d-none d-md-block">TID INVESTMENT</h2>
					<p class="px-3" id="wd">	Wouldn’t it be great if you didn’t have to wait for a paycheck every month? Wouldn’t you love not having to struggle to keep your transactions down to the limit? And what if you didn’t have to save for a whole year to get your dream vacation or car. You work so hard for your money shouldn’t you allow money work for you this time? That’s why we are offering you attractive returns on your investments. Watch your money return the favour..... <a href="registration.php" target="_blank" id="bt"><strong>Sign up</a></strong></p>
				</div>
				<div class="col-md-6" id="img4">
					<img src="image/money.jpg" alt="pic" style="height: 350px;">
				</div>
			</div>

				<!-- End of coy narration with imge -->

	
					<!-- Begining of FAQ  -->

					<div class="row" id="faq">
						<div class="col">
							<h2 style="color: white;" id="faqborder">FAQ</h2>
							<div class="accordion" id="accordionExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingOne">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
       How much can i borrow?
      </button>
    </h2>
    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Our minimum loan amount is N50,000 and the upper limit for a new customer is N1, 000, 000. Both depend on borrower’s capacity to repay based on verifiable income level and other selection criteria</strong>
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        How long does it take to process a loan?
      </button>
    </h2>
    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Loan processing takes less than 24 hours. Once your application has been approved, the loan will be disbursed into your individual account in less than 24 hours.</strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Do i have to be in paid employment to get your loans?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>No,not neccessarily.</strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Who can access TID loan?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>TID loans are currently available to salary earners, business owners, and entreprenuer living Lagos.</strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Can my loan application be rejected?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingFive" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Yes it can. Your application goes through an approval process and if it does not meet the set criteria, the loan request is rejected.</strong> 
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Who can access TID loan?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>TID loans are currently available to salary earners, business owners, and entreprenuer living Lagos.</strong> 
      </div>
    </div>
  </div>
    <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        What's TID loan interest loan?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>TID loan interest is 10% per month.</strong> 
      </div>
    </div>
  </div>
    <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        How do i make repayment on my loan?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Our primary repayment channel is via REMITA for ease of repayment and reconciliation. However, we have secondary repayment channels like Direct Debit Mandate (DDM), online repayments and cheques.</strong> 
      </div>
    </div>
  </div>
      <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Is their any charges?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Yes, management process fee of 0.5% willbe charged.</strong> 
      </div>
    </div>
  </div>
      <div class="accordion-item">
    <h2 class="accordion-header" id="headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Is their any default charge on loan repayment?
      </button>
    </h2>
    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingSix" data-bs-parent="#accordionExample">
      <div class="accordion-body">
        <strong>Yes, which ever is higher, N1,000 or 1% of principal loan amount will be charged per day.</strong> 
      </div>
    </div>
  </div>
</div>
</div>
</div>
			
				<?php

				include_once("footer.php");

				?>
					
						</div>


				
       

			
			




				

				<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.js">




			</script>	
	</body>
	</html>