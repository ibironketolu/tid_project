<?php 

include_once "../headers/admin_header.php"; ?>
<!---Page content --->
<div class="container">
	<h1 class="mt-4 mb-3">
		<small>Reject Loan</small>
	</h1>
	<?php if (isset($_REQUEST['btnreject'])){
		#delete club
		include_once '../shared/loan.php';
		//create object
		$obj = new Loan();
		//make use of delete method
		$obj->updateLoanDetails2($_REQUEST['loanid']);
        $msg = "no action performed";
        header("Location:allloans.php?info=$msg");
			exit();
		}


		if (isset($_REQUEST['btncancel'])) {
			#redirect to list clubs
			$msg = "no action performed";
			header("Location:allloans.php?info=$msg");
			exit();
		}



	?>
		

	<div class="row">
		<div class="col-lg-8 mb-4">
			<?php 
			if (isset($_REQUEST['loanid'])){
			 ?>
			<div class="alert alert-danger">
				<h3>Are you sure u want to Reject</h3>
			</div>
			<form method="post" action="rejectloan.php?loanid=<?php echo $_REQUEST['loanid']?>">
			<button type="submit" name="btnreject" class="btn btn-danger">Yes</button>
			<button type="submit" name="btncancel" class="btn btn-secondary">No</button>
			</form>
			<?php 
				}
			 ?>
		</div>
	</div>

</div>








