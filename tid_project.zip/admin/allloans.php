<?php include_once("../headers/admin_header.php"); ?>

<?php  
 include_once "../headers/admin_header.php";
?>
<style type="text/css">

.container 
{
    width:600px;
    margin:34px auto -34px;
    border: 3px solid #111d57 ;
}
.head .title h1
{
    text-align: center;
    font-weight: bold;
    font-size: 43px;
    text-transform: capitalize;
    font-family: Arial, Helvetica, sans-serif;
    padding:16px 0 0 0;
    color:white;
}
.head .title
{
    background-color: #111d57;
    height:83px;
    margin: -29px 0 0 0;
}

form .first .clear
{
    clear:both;

}
.first,.last,.email,.pass,.cpass
{
    margin:12px 0 13px 20px;
    padding:12px 0 0 0;
}
.first label,
.last label,
.email label,
.pass label,
.cpass label
{
    text-transform: capitalize;
    font-weight:bold;
    font-family: Arial, Helvetica, sans-serif;
    color:#111d57;
}
.first input,
.last input,
.email input,
.pass input,
.cpass input
{
    width:90%;
    height:33px;
    margin: 11px 0 3px 0;
    text-transform: capitalize;
    padding: 0 0 0 10px;
    background-color: #D8D8D8;
    border: none;
}
.submit
{
    margin:0 0 0 19px;
}
.submit input[type="submit"]
{
    background-color:#111d57;
    color:white;
    font-weight: bold;
    margin:0 0 20px 0;
    font-family: Arial, Helvetica, sans-serif;
    border-radius: 25px;
    font-size: 20px;
    text-transform: capitalize;
    width:160px;
    height:33px;
    text-align:center;
    padding:4px 10px 2px 10px;
}
.submit input[type="submit"]:hover
{
    background-color:##111d57;
}
form
{
    margin:-12px 0 0 0px;
    background-color: white;
}

table { 
	width: 750px; 
	border-collapse: collapse; 
	margin:50px auto;
	}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #eee; 
	}

th { 
	background: #3498db; 
	color: white; 
	font-weight: bold; 
	}

td, th { 
	padding: 10px; 
	border: 1px solid #ccc; 
	text-align: left; 
	font-size: 18px;
	}

/* 
Max width before this PARTICULAR table gets nasty
This query will take effect for any screen smaller than 760px
and also iPads specifically.
*/
@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	table { 
	  	width: 50%; 
	}

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);

		color: #000;
		font-weight: bold;
	}

}
</style>

  <table class="table table-striped table-bordered">
  <h2 class="text-center">All Loan Request</h2>
  <thead >
    <tr style="background-color: #428bca;">
     <?php $kounter = 0  ?>;
      <th>#</th>
      <th>Full name</th>
      <th>Loan Amount</th>
      <th>Loan Duration</th>
      <th>Bvn</th>
      <th>Rate</th>
      <th>Bank Name</th>
      <th>Account Number</th>
      <th>Date Request</th>
      <th>Repayment Date</th>
      <th>Approval status</th>
      <th>Action</th>

    </tr>
  </thead>
  <tbody>
  <?php 
  include_once "../shared/loan.php";
     
     $obj = new Loan();

     $output = $obj->allLoanRequest();

    //  echo "<pre>";
    //  print_r($output);
    //  echo "</pre>";
     
     if (count($output)>0) {
     foreach ($output as $key => $value) {
        $loan_id = $value['Loan_id'];
        $fullname = $value['First_name']." ".$value['Middle_name']." ".$value['Last_name'];
        $rate = $value['Interest_rate'];
        $loan_amount = $value['Loan_amount'];
        $loan_duration= $value['Loan_duration'];
        $bvn = $value['Bvn'];
        $date_request = $value['Date_request'];
        $repayment_date = $value['Repayment_date'];
        $approval_status = $value['Approval_status'];
        $bank_name = $value['name'];
        $account_no = $value['Account_no']
     
    
     ?>
    <tr>
    <td><?php echo ++$kounter ?></td>
    <td><?php echo $fullname ?></td>
    <td><?php echo "₦ ".$loan_amount ?></td>
    <td><?php echo $loan_duration ?></td>
    <td><?php echo $bvn ?></td>
    <td><?php echo $rate." %" ?></td>
    <td><?php echo $bank_name ?></td>
    <td><?php echo $account_no ?></td>
    <td><?php echo $date_request ?></td>
    <td><?php echo $repayment_date ?></td>
    <td><?php echo $approval_status ?></td>
    <td><a href="acceptloan.php?loanid=<?php echo $loan_id ?>" >Accept Loan</a><span> | </span>
        <a href="rejectloan.php?loanid=<?php echo $loan_id ?>" >Reject Loan</a>
    </td>
    </tr>
    <tr>
  </tbody>
<?php
}
}

?>
</table>

  <?php include_once("../headers/admin_footer.php"); ?>
