<?php 

include_once "../headers/admin_header.php"; ?>
<!---Page content --->
<div class="container">
	<h1 class="mt-4 mb-3">
		<small>Approve Investment Investment</small>
	</h1>
	<?php if (isset($_REQUEST['btnaccept'])){
		#delete club
		include_once '../shared/investment.php';
		//create object
		$obj = new Investment();
		//make use of delete method
		$obj->updateInvestmentDetails($_REQUEST['investmentid']);
        $msg = "no action performed";
        header("Location:allinvestment.php?info=$msg");
			exit();
		}


		if (isset($_REQUEST['btncancel'])) {
			#redirect to list clubs
			$msg = "no action performed";
			header("Location:allinvestment.php?info=$msg");
			exit();
		}
 
	?>
		

	<div class="row">
		<div class="col-lg-8 mb-4">
			<?php 
			if (isset($_REQUEST['investmentid'])){
			 ?>
			<div class="alert alert-danger">
				<h3>Are you sure u want to Appprove Investment </h3>
			</div>
			<form method="post" action="approveinvestment.php?investmentid=<?php echo $_REQUEST['investmentid']?>">
			<button type="submit" name="btnaccept" class="btn btn-danger">Yes</button>
			<button type="submit" name="btncancel" class="btn btn-secondary">No</button>
			</form>
			<?php 
				}
			 ?>
		</div>
	</div>

</div>








