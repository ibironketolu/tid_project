<?php  
 include_once "../headers/admin_header.php";
?>
<style type="text/css">

.container 
{
    width:600px;
    margin:34px auto -34px;
    border: 3px solid #111d57 ;
}
.head .title h1
{
    text-align: center;
    font-weight: bold;
    font-size: 43px;
    text-transform: capitalize;
    font-family: Arial, Helvetica, sans-serif;
    padding:16px 0 0 0;
    color:white;
}
.head .title
{
    background-color: #111d57;
    height:83px;
    margin: -29px 0 0 0;
}

form .first .clear
{
    clear:both;

}
.first,.last,.email,.pass,.cpass
{
    margin:12px 0 13px 20px;
    padding:12px 0 0 0;
}
.first label,
.last label,
.email label,
.pass label,
.cpass label
{
    text-transform: capitalize;
    font-weight:bold;
    font-family: Arial, Helvetica, sans-serif;
    color:#111d57;
}
.first input,
.last input,
.email input,
.pass input,
.cpass input
{
    width:90%;
    height:33px;
    margin: 11px 0 3px 0;
    text-transform: capitalize;
    padding: 0 0 0 10px;
    background-color: #D8D8D8;
    border: none;
}
.submit
{
    margin:0 0 0 19px;
}
.submit input[type="submit"]
{
    background-color:#111d57;
    color:white;
    font-weight: bold;
    margin:0 0 20px 0;
    font-family: Arial, Helvetica, sans-serif;
    border-radius: 25px;
    font-size: 20px;
    text-transform: capitalize;
    width:160px;
    height:33px;
    text-align:center;
    padding:4px 10px 2px 10px;
}
.submit input[type="submit"]:hover
{
    background-color:##111d57;
}
form
{
    margin:-12px 0 0 0px;
    background-color: white;
}

table { 
	width: 750px; 
	border-collapse: collapse; 
	margin:50px auto;
	}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #eee; 
	}

th { 
	background: #3498db; 
	color: white; 
	font-weight: bold; 
	}

td, th { 
	padding: 10px; 
	border: 1px solid #ccc; 
	text-align: left; 
	font-size: 18px;
	}

/* 
Max width before this PARTICULAR table gets nasty
This query will take effect for any screen smaller than 760px
and also iPads specifically.
*/
@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);

		color: #000;
		font-weight: bold;
	}

}
</style>

<div class="head">
            <div class="container">
                <div class="title">
                    <h1>Add Investment Type</h1>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container">
                    <form action ="" method ="POST">

             <?php 
            include_once "../shared/investment.php";
             if ($_SERVER['REQUEST_METHOD']=='POST'){     
                $invest_name = $_POST['invest_type'];
                $interest_rate = $_POST['interest-rate'];
            $obj = new Investment;
            $output = $obj->addInvestment($invest_name,$interest_rate);
                if ($output == true) {
                    echo "<div class='alert alert-success'>You have successfully added a new type of Loan</div>";
                } else {
                    echo "<div class='alert alert-danger'>Oops! Error Occured</div>";

                }
                
             }

            ?>
               <div class="first">
                  <label for="first">Investment Type:</label>
                      <div class="clear"></div>
                          <input type="text" name="invest_type" id="first" placeholder="enter Investment type" required>
                        </div>
                        <div class="last">
                            <label for="last">Interest Rate:</label>
                            <div class="clear"></div>
                            <input type="text" name="interest-rate" id="last" placeholder="enter interest rate" required>
                        </div>
                        <div class="submit">
                            <input type="submit" value="Add Investment">
                        </div>
                    </form>
            </div>
        </div>

  <table>
  <thead>
    <tr>
     <?php $kounter = 0  ?>;
      <th>#</th>
      <th>Investment Type</th>
      <th>Interest Rate</th>
    </tr>
  </thead>
  <tbody>
  <?php 
  include_once "../shared/investment.php";
     
     $obj = new Investment();

     $output = $obj->allInvestmentType();
     
     if (count($output)>0) {
     foreach ($output as $key => $value) {
        $name = $value['invest_name'];
        $rate = $value['Invest_interest'];
     
     ?>

    <tr>
      <td><?php echo ++$kounter ?></td>
      <td><?php echo $name ?></td>
      <td><?php echo $rate." % " ?></td>
      <!-- <td><a href="editinvestment.php" target="_blank">Edit Loan</a><span> | </span>
        <a href="deleteinvestment.php" target="_blank">Delete Loan</a>
    </td> -->
    </tr>
    <tr>
  </tbody>
<?php
     }
    }
?>
</table>