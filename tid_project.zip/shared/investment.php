<?php
 include_once "constant.php";

class Investment{

    public $invest_name;
    public $interest_rate;
    public $dbcon;

public function __construct(){
    $this->dbcon = new mysqli(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_DATABASENAME);
    if ($this->dbcon->connect_error) {
        die("Failed".$this->this->connect_error);
    } 

}

public function addInvestment($customer_id,$amount,$invest_type,$maturity){
    $statement = $this->dbcon->prepare("INSERT INTO investment (Customer_id,invest_amount,invest_type_id,Maturity_date) VALUES(?,?,?,?)");
    $statement->bind_param("isis",$customer_id,$amount,$invest_type,$maturity);
    $statement->execute();
    $statement->get_result();
     if ($statement->affected_rows == 1) {
        return true;
     } else {
        return false;
     }
     
} //end of the add loan function


public function allInvesttype(){
    $statement = $this->dbcon->prepare("SELECT * FROM invst_type");
    $statement->execute();
    $result = $statement->get_result();
    // fetch records
			$records = array();
			if ($result->num_rows > 0){
				while ($row = $result->fetch_assoc()){
					$records[] = $row;
				}
			}

			return $records;
		}



public function allInvestmentType(){
$statement = $this->dbcon->prepare("SELECT * FROM invst_type");
$statement->execute();
$result = $statement->get_result();
// fetch records
        $records = array();
        if ($result->num_rows > 0){
            while ($row = $result->fetch_assoc()){
                $records[] = $row;
            }
        }

        return $records;
    }

    public function allInvestRequest(){
        $statement = $this->dbcon->prepare("SELECT * FROM investment JOIN customer ON investment.Customer_id = customer.Customer_id JOIN invst_type ON investment.invest_type_id = invst_type.invst_type_id");
        
        $statement->execute();
        
        $result = $statement->get_result();
        
        $records = array();
        
        if($result->num_rows >0){
                while($row = $result->fetch_assoc()){
                    $records[] = $row;
                }
        
        }
        
        return $records;
        
        }	


        public function updateInvestmentDetails($investment_id){
            $statement= $this->dbcon->prepare("UPDATE investment SET Approval_status = ? WHERE Investment_id =? ");
        
            $Approval_status = "completed";
        
            $statement->bind_param("si",$Approval_status,$investment_id);
        
            $statement->execute();
            if ($statement->affected_rows == 1) {
                return true;
             } else {
                return false;
             }
             
        } //end of the add loan function
        
        public function updateInvestmentDetails2($investment_id){
            $statement= $this->dbcon->prepare("UPDATE investment SET Approval_status = ? WHERE Investment_id =? ");
        
            $Approval_status = "failed";
        
            $statement->bind_param("si",$Approval_status,$investment_id);
        
            $statement->execute();
            if ($statement->affected_rows == 1) {
                return true;
             } else {
                return false;
             }
             
        } //end of the add loan function


        public function completedInvestment(){
            $statement= $this->dbcon->prepare("SELECT Investment_id FROM investment WHERE Approval_status = 'completed' ");
        
            $statement->execute();
        
            $statement->store_result();
        
            return $statement->num_rows;
        
        
        
        }
        public function Totalinvestors(){
            $statement= $this->dbcon->prepare("SELECT Investment_id FROM investment ");
        
            $statement->execute();
        
            $statement->store_result();
        
            return $statement->num_rows;
        
        
        
        }

        public function failedInvestment(){
            $statement= $this->dbcon->prepare("SELECT Investment_id FROM investment WHERE Approval_status = 'failed' ");
        
            $statement->execute();
        
            $statement->store_result();
        
            return $statement->num_rows;
        
        
        
        }
        
        public function pendingInvestment(){
            $statement= $this->dbcon->prepare("SELECT Investment_id FROM investment WHERE Approval_status = 'pending' ");
        
            $statement->execute();
        
            $statement->store_result();
        
            return $statement->num_rows;
        
        
        
        }

//end of the class Investment
}


?>