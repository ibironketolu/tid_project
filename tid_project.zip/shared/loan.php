<?php
 include_once "constant.php";

class Loan{

    public $loan_name;
    public $interest_rate;
    public $dbcon;

public function __construct(){
    $this->dbcon = new mysqli(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_DATABASENAME);
    if ($this->dbcon->connect_error) {
        die("Failed".$this->this->connect_error);
    } 

}

public function addLoan($loan_name,$interest_rate){
    $statement = $this->dbcon->prepare("INSERT INTO loan_type (loan_name,loan_rate) VALUES(?,?)");
    $statement->bind_param("si",$loan_name,$interest_rate);
    $statement->execute();
    $statement->get_result();
     if ($statement->affected_rows == 1) {
        return true;
     } else {
        return false;
     }
     
} //end of the add loan function


public function allLoan(){
    $statement = $this->dbcon->prepare("SELECT * FROM loan_type");
    $statement->execute();
    $result = $statement->get_result();
    // fetch records
			$records = array();
			if ($result->num_rows > 0){
				while ($row = $result->fetch_assoc()){
					$records[] = $row;
				}
			}

			return $records;
		}


public function allLoanRequest(){
$statement = $this->dbcon->prepare("SELECT * FROM loan JOIN customer ON loan.Customer_id = customer.Customer_id JOIN banks ON customer.Bank_id = banks.id");

$statement->execute();

$result = $statement->get_result();

$records = array();

if($result->num_rows >0){
        while($row = $result->fetch_assoc()){
            $records[] = $row;
        }

}

return $records;

}	


public function completedLoan(){
    $statement= $this->dbcon->prepare("SELECT Loan_id FROM loan WHERE Approval_status = 'completed' ");

    $statement->execute();

    $statement->store_result();

    return $statement->num_rows;



}

public function failedLoan(){
    $statement= $this->dbcon->prepare("SELECT Loan_id FROM loan WHERE Approval_status = 'failed' ");

    $statement->execute();

    $statement->store_result();

    return $statement->num_rows;



}

public function pendingLoan(){
    $statement= $this->dbcon->prepare("SELECT Loan_id FROM loan WHERE Approval_status = 'pending' ");

    $statement->execute();

    $statement->store_result();

    return $statement->num_rows;



}

public function updateLoanDetails($loan_id){
    $statement= $this->dbcon->prepare("UPDATE Loan SET Approval_status = ? WHERE loan_id =? ");

    $Approval_status = "completed";

    $statement->bind_param("si",$Approval_status,$loan_id);

    $statement->execute();
    if ($statement->affected_rows == 1) {
        return true;
     } else {
        return false;
     }
     
} //end of the add loan function

public function updateLoanDetails2($loan_id){
    $statement= $this->dbcon->prepare("UPDATE Loan SET Approval_status = ? WHERE loan_id =? ");

    $Approval_status = "failed";

    $statement->bind_param("si",$Approval_status,$loan_id);

    $statement->execute();
    if ($statement->affected_rows == 1) {
        return true;
     } else {
        return false;
     }
     
} //end of the add loan function






//end of the class Loan
}


?>