<?php

	// database connection constants

define("DB_HOST", "localhost");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
define("DB_DATABASENAME", "tid_projectdb");

// application name
define("APP_NAME", "TID LOAN");



?>