<?php 
include_once "constant.php";

class Admin{
    public $firstname;
	public $middlename;
	public $lastname;
	public $emailaddress;
	public $password;
	public $dbcon;

    public function __construct(){
        $this->dbcon = new mysqli(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_DATABASENAME);
        if ($this->dbcon->connect_error) {
           die("Failed".$this->dbcon->connect_error);
        }
    }

    public function insertAdmin($fname,$mname,$lname,$email,$password){

		// hash password
		$pswd = password_hash($password, PASSWORD_DEFAULT);

		// prepare statement
		$statement = $this ->dbcon ->prepare("INSERT INTO admin(First_name, Middle_name, Last_name , Email_address, Password) VALUES (?,?,?,?,?)");
		// bind the parameter
		$statement ->bind_param("sssss",$fname,$mname,$lname,$email,$pswd);

		// execute

		$statement ->execute();

		// check if record was inserted

		if($statement->affected_rows == 1){
			return true;
		}else{
			return false;
		}

	}


 //Create Admin login
    public function adminLogin($email,$password){

    $statement = $this->dbcon->prepare("SELECT * FROM admin WHERE Email_address = ?");

    $statement->bind_param("s",$email);

    $statement->execute();

    $result = $statement->get_result();


    if ($result->num_rows == 1){
        $row = $result->fetch_assoc();

        // verify password
        if (password_verify($password, $row['Password'])){
            // password match, then create session variable

            session_start();

            $_SESSION['admin_id'] = $row['Admin_id'];
            $_SESSION['admin_first_name'] = $row['First_name'];
            $_SESSION['admin_last_name'] = $row['Last_name'];

            $_SESSION['admin_email'] = $row['Email_address'];

            return true;
        }else{
            // email address doesn't match
            return false;
        }

    }else{
          // email address doesn't exist
          return false;
      }

  }







//end of the class Admin
}






?>