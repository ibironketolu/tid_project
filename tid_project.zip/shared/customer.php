<?php
include_once("constant.php");

// class definition

class Customer{
	// member variables
	public $firstname;
	public $middlename;
	public $lastname;
	public $phonenumber;
	public $dob;
	public $emailaddress;
	public $gender;
	public $address;
	public $password;
	public $dbcon;

	// member functions

	public function __construct(){
			// create obj mysqli
		$this ->dbcon = new MySQLi(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASENAME);

		// check if connected to db
		if($this->dbcon->connect_error){
			die("Connection Failed:".$this->dbcon->connect_error);
		}
		
	}
	// startMesssage method begins here
	public function Insertcustomer($fname, $mname, $lname,$bank_id,$account_no,$bvn,$phone, $dob, $email, $gender, $address, $password){
		
		// hash password

		$pswd = password_hash($password, PASSWORD_DEFAULT);

		// prepare statement
		$statement = $this ->dbcon ->prepare("INSERT INTO customer(First_name, Middle_name, Last_name,Bank_id,Account_no,Bvn,Phone_number, Date_of_birth, Email_address, Gender, Address, Password) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
		// bind the parameter
		$statement ->bind_param("sssiiissssss",$fname,$mname,$lname,$bank_id,$account_no,$bvn,$phone,$dob,$email,$gender,$address,$pswd);

		// execute

		$statement ->execute();

		// check if record was inserted

		if($statement->affected_rows == 1){
			return true;
		}else{
			return false;
		}

	}


	# begin login
	function login($email, $password){
		// prepare statement
		$statement = $this->dbcon->prepare("SELECT * FROM customer  WHERE Email_address = ?");

		// bind the parameter
		$statement->bind_param("s", $email);

		// execute
		$statement->execute();

		//get result
		$result = $statement->get_result();

		// fetch record
		if ($result->num_rows == 1){
			$row = $result->fetch_assoc();

			// verify password
			if (password_verify($password, $row['Password'])){
				// password match, then create session variable

				session_start();

				$_SESSION['customer_id'] = $row['Customer_id'];
				$_SESSION['name'] = $row['First_name'];
				$_SESSION['myemail'] = $row['emailaddress'];

				return true;
			}else{
				// email address doesn't match
				return false;
			}

		}else{
			  // email address doesn't exist
			  return false;
		  }
	}


	public function allBanks(){
		//prepare statement for the database to interact with
	$statement = $this->dbcon->prepare("SELECT * FROM banks");


		//execute
	$statement->execute();

	//get result
	$result = $statement->get_result();


	//fetch records
	$records = array();

	if($result->num_rows >0){
			while($row = $result->fetch_assoc()){
				$records[] = $row;
			}

	}

	return $records;









	} #end of function class

	public function applyLoan($customer_id, $amount, $interest_rate,$loan_type,$loan_duration,$repayment_date){
		
		// hash password

		// prepare statement
		$statement = $this ->dbcon ->prepare("INSERT INTO loan(Customer_id, Loan_amount,Interest_rate,Loan_type_id,Loan_duration, Repayment_date) VALUES (?,?,?,?,?,?)");
		// bind the parameter
		$statement ->bind_param("isisss",$customer_id, $amount, $interest_rate,$loan_type,$loan_duration,$repayment_date);

		// execute

		$statement ->execute();

		// check if record was inserted

		if($statement->affected_rows == 1){
			return true;
		}else{
			return false;
		}

	}



	public function totalCustomer(){
		$statement= $this->dbcon->prepare("SELECT Customer_id FROM customer");

		$statement->execute();

		$statement->store_result();

		return $statement->num_rows;



	}

	public function getPendingLoan($cust_id){
		//prepare the statement

	$statement=$this->dbcon->prepare("SELECT * FROM loan WHERE Customer_id =? AND Approval_status ='pending' ");

	$statement->bind_param("i",$cust_id);

	$statement->execute();

	$statement->store_result();

	return $statement->num_rows;


}

public function getApprovedLoan($cust_id){
	//prepare the statement

$statement=$this->dbcon->prepare("SELECT * FROM loan WHERE Customer_id =? AND Approval_status ='completed' ");

$statement->bind_param("i",$cust_id);

$statement->execute();

$statement->store_result();

return $statement->num_rows;


}

public function getFailedLoan($cust_id){
	//prepare the statement

$statement=$this->dbcon->prepare("SELECT * FROM loan WHERE Customer_id =? AND Approval_status ='failed' ");

$statement->bind_param("i",$cust_id);

$statement->execute();

$statement->store_result();

return $statement->num_rows;


}



public function getPendingInvestment($cust_id){
	//prepare the statement

$statement=$this->dbcon->prepare("SELECT * FROM investment WHERE Customer_id =? AND Approval_status ='pending' ");

$statement->bind_param("i",$cust_id);

$statement->execute();

$statement->store_result();

return $statement->num_rows;


}


public function getApprovedInvestment($cust_id){
	//prepare the statement

$statement=$this->dbcon->prepare("SELECT * FROM investment WHERE Customer_id =? AND Approval_status ='completed' ");

$statement->bind_param("i",$cust_id);

$statement->execute();

$statement->store_result();

return $statement->num_rows;


}



public function getFailedInvestment($cust_id){
	//prepare the statement

$statement=$this->dbcon->prepare("SELECT * FROM investment WHERE Customer_id =? AND Approval_status ='failed' ");

$statement->bind_param("i",$cust_id);

$statement->execute();

$statement->store_result();

return $statement->num_rows;


}

//end of the customer login
}

?>