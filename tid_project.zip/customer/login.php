<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">

</head>
<body>
  
</body>
</html>
<?php

// start session for redirecting to another page
session_start();

// CHECK if the user clicked on the login button

if($_SERVER['REQUEST_METHOD'] =='POST'){
// include class file
  include_once("../shared/customer.php");

  // create object of user class
  $userloan = new Customer();

  // make reference to the login

  $output = $userloan->Login($_POST['email'], $_POST['password']);

  if ($output == false){
    echo "<div class='alert alert-danger'>invalid username or password</div>";

  }else{
         // login successful, the redirect to landing page we make use of header and alway end header with exit()
        header("location: dashboard.php");
        exit();
  }
}

?>













<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Customer Login</title>
	<script type="text/javascript" src="js/bootstrap.bundle.js">
</script>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
		<style type="text/css">
body {
  height: 100%;
}

body {
  display: flex;
  align-items: center;
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #f5f5f5;
}

.form-signin {
  width: 100%;
  max-width: 330px;
  padding: 15px;
  margin: auto;
}

.form-signin .checkbox {
  font-weight: 400;
}

.form-signin .form-floating:focus-within {
  z-index: 2;
}

.form-signin input[type="email"] {
  margin-bottom: -1px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.form-signin input[type="password"] {
  margin-bottom: 10px;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}





</style>
<link rel="stylesheet" type="text/css" href="../fontawsome/css/all.css">	
</head>
<body  class="text-center">

	<div class="container">

    <?php

    if (isset($error)){
      echo $error;
    }

    if(isset($_REQUEST['u'])){
      echo "<div class='alert alert-danger alert-dismissible fade show'>".$_REQUEST['u']."</div>";
      ?>
       <script type="text/javascript">
          alert('<?php echo $_REQUEST['u']; ?>')
        </script>
      <?php

    }
    ?>
		
		<div class="row">
			<div class="col-md-6">
	 <form method="POST" action="">
  
    <img class="mb-4" src="../image/ttt.jpg" alt="" width="72" height="57">
    <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

    <div class="form-floating">
      <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com" name="email">
      <label for="floatingInput">Emailaddress</label>
    </div>
    <div class="form-floating">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password">
      <label for="floatingPassword">Password</label>
    </div>

    <div class="checkbox mb-3">
      <label>
        <input type="checkbox" value="remember-me"> Remember me
      </label>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="submit" name="login">Login</button>
   
  </form>
			</div>
			<div class="col-md-6">
				<img src="../image/ttt.jpg" alt="myphoto">
			</div>
		</div>





	</div>

</body>
</html>