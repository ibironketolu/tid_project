<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
					<meta name="keywords" content="TID LOAN"/>
	<meta name="description" content="TID loan offer quick loan within 24rs, we offer short & long term of investment and operate 24hrs."/>
	<meta name="Keywords" content="loan, quick loan, instant loan, short-term investment,long-term investment, 24hrs loan in lagos, 10% interest loan rate, 15% interest loan rate, low interest loan, less paper work loan, 1m loan service, loan company, licenced financial loan company, no collateral loan,rent loan, school fees loan, car loan services, business loan, pay small small loan installment"/>
	<meta name="Author" content="TID LOAN SERVICES"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
	<title>Customer Registration Form</title>
	<script type="text/javascript" src="js/bootstrap.bundle.js">
</script>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
		<style type="text/css">

#mainDiv{
	
	

}

#nav{
	background-color: #111D57;
	color: white;
	position: sticky;
	
}

#nav2{
	font-size: 20px;
	margin-left: 30%;
	margin-top: 1%;


}

#nav1{
	margin-top: 1%;
	margin-bottom: 1%;
}

#regform{
	width: 50%;
	margin-left: 25%;
}

#form{
  
 margin-left: 1%;
 background-color:#111D57 ;
}

h3{
	text-align: center;
	
	border-radius: 10%;
	margin-top: 1%;
	width: 70%;
	margin-left: 15%;
	color: white;
}

label{
	color: white;
	font-size: 18px;

}



#copy{
				color:white ;
				text-align: center;
				border: 2px solid white;
				background-color: #111D57;
			}
#carousel{
	width: 70%;
}
#footer{
	
	height: 230px;
	margin-top: 2%;
	background-color:#111D57 ;
	color: white;
}



</style>
<link rel="stylesheet" type="text/css" href="../fontawsome/css/all.css">	
</head>
<body>

		<div class="container-fluid" id="mainDiv">
			<!-- Begining of Nav bar -->
	<div class="row" id="nav">
		<div class="col" id="nav1">
	<a class="navbar-brand" href="index.html"><img src="../image/ttt.jpg" width='100' height="60"></a>
		</div>
		<div class="col" id="nav2">
			<nav class="navbar navbar-expand-lg navbar-white ">
  <div class="container-fluid">
 
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarSupportedContent">
      <ul class="navbar-nav " id="text">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html" style="color:white">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../about.php" style="color:white">About us</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" style="color:white">
            Service
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="loan.html">Loan</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="investment.html">Investment</a></li>
        </ul>
                <li class="nav-item">
          <a class="nav-link" href="login.php" style="color:white" >Customer Log-in</a>
        </li>
        </li>
       
      </ul>
     
    </div>
  </div>
</nav>
		</div>
	</div>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){

include_once "../shared/customer.php";

$obj = new Customer;

//create an ouptut for the customer

$fname = $_POST['firstname'];
$mname = $_POST['middlename'] ;
$lname =$_POST['lastname'] ;
$bank_id =$_POST['bank_type'];
$account_no = $_POST['account_no'];
$bvn = $_POST['bvn'];
$phone =$_POST['phone'] ;
$dob = $_POST['dob'] ;
$email = $_POST['email'] ;
$gender = $_POST['gender'] ;
$address = $_POST['address'] ;
$password = $_POST['password'];



$output = $obj->insertCustomer($fname, $mname, $lname,$bank_id,$account_no,$bvn,$phone, $dob, $email, $gender, $address, $password);

if ($output == true){
	echo "<div class='alert alert-success'>Registration successful .. you can now login</div>";
	header("location:login.php");
}else{
	echo "<div class='alert alert-danger'>Oops! An Error Occured</div>";
}

}
?>





		<!-- begining of Registration Form -->
		<div class="row mt-3" id="regform">
			<div class="col" id="form">
				<h3>Customer Registration Form</h3>
				<form method="POST" action="">
					<div>
						<label for="firstname" class="form-label">First Name</label>
						<input type="text" name="firstname" id="firstname" class="form-control" required/>
					</div>
					<div>
						<label for="middlename" class="form-label">Middle Name</label>
						<input type="text" name="middlename" id="middlename" class="form-control" required/>
					</div>
					<div>
						<label for="lastname" class="form-label">Last Name</label>
						<input type="text" name="lastname" id="lastname" class="form-control" required/>
					</div>
						<div>
						<label for="email" class="form-label">Email Address</label>
						<input type="text" name="email" id="email" class="form-control" required/>
					</div>
					<div>
						
						<label for="phone" class="form-label">Bank</label>
						<select name="bank_type" id="bank_type" class="form-select">
						<option value="Choose Loan"> Choose Bank</option>
						<?php
						#create a new object of the class category
						include_once "../shared/customer.php";

						$obj = new Customer();

						$output= $obj->allBanks();

						foreach ($output as $key => $value) {
						$bank_name = $value['name'];
						$bank_id = $value['id'];

						echo "<option value='$bank_id'>$bank_name</option>";
						}


						?>
						</select>
					</div>
					<div>
						<label for="phone" class="form-label">Account Number</label>
						<input type="number" name="account_no" id="phone" class="form-control" required/>
					</div>
					<div>
						<label for="phone" class="form-label">BVN</label>
						<input type="number" name="bvn" id="phone" class="form-control" required/>
					</div>
					<div>
						<label for="phone" class="form-label">Phone Number</label>
						<input type="text" name="phone" id="phone" class="form-control" required/>
					</div>
					<div>
						<label for="password" class="form-label">Password</label>
						<input type="password" name="password" id="password" class="form-control" required/>
					</div>
					<div>
						<label for="gender" class="form-label">Gender</label>
						<input type="text" name="gender" id="gender" class="form-control" required/>
					</div>
					<div >
					<label>Date of Birth:</label>
					<input type="date" class="form-control" id="dob" name='dob' required>
					</div>
					<div >
					<label>Address:</label>
					<textarea  name="address" class="form-control">

					</textarea>
					</div>
					<br>
					<button type="submit" class="btn btn-success" name="btnSubmit">Submit</button>
				</form>
				<br>

				<br>
			</div>
	
		</div>

		<!-- end of Registration form -->

	<!-- Begining of footer -->
					<div class="row" id="footer">
						<div class="col mt-3">
							<h3>CONTACT US </h3>
							<i class="fa-solid fa-envelope fa-1x"></i> tidloanfinance@gmail.com<br>
							<i class="fa-solid fa-phone"></i> +2349069224767<br>
							<i class="fa fa-globe"></i> 2b Bola Onasanya street off Adio-Somoye Street<br>Ogudu, Gra, Ogudu. Ojota <br>Lagos, Nigeria.
						</div>
						<div class="col mt-3">
							<a href=""><img src="../image/twitter.png" alt="twit" style="height:70px"></a>
						<p>Reach us via</p>
						</div>
						<div class="col mt-3">
							<a href=""><img src="../image/facebook2.png" alt="twit" style="height:70px"></a>
						<p>Reach us via </p>
						</div>
						<div class="col mt-3">
							<a href=""><img src="../image/linked_in.png" alt="twit" style="height:70px"></a>
						<p>Reach us via </p>
						</div>
							
						
					</div>

					<!-- End of filter -->

							<!-- copywrite -->

						<div class="row" id="copy">
							<div class="col">

								<span><strong>&#169; 2022 TID Loan and Finace. All Rights Reserved</strong></span>
							</div>
						</div>

							<!-- End of coywrite -->
			
		</div>

</body>
</html>